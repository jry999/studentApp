package com.wipro.student.exeception;

public class StudentException extends RuntimeException{

	public StudentException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
